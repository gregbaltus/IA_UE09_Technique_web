import ArticleRepository from "./repository/articleRepository.js";
import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = 3000;

const articleRepo = new ArticleRepository();

app.use(express.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, "public")));

app.get("/api/articles", (req, res) => {
  articleRepo.getAllArticles((err, articles) => {
    if (err) {
      return res.status(500).json({ error: "Erreur lors de la récupération des articles" });
    }
    res.json(articles);
  });
});

app.get("/api/articles/:id", (req, res) => {
  const id = req.params.id;
  articleRepo.getArticleById(id, (err, article) => {
    if (err) {
      return res.status(500).json({ error: "Erreur serveur" });
    }
    if (!article) {
      return res.status(404).json({ error: "Article non trouvé" });
    }
    res.json(article);
  });
});

app.post("/ajouter", (req, res) => {
  const { titre, contenu } = req.body;

  if (!titre || !contenu) {
    return res.redirect("/ajout.html?etat=erreur");
  }

  articleRepo.insertArticle(titre, contenu, (err) => {
    if (err) {
      return res.redirect("/ajout.html?etat=erreur");
    }
    res.redirect("/ajout.html?etat=ok");
  });
});

app.listen(PORT, () => {
  console.log(`Serveur démarré sur http://localhost:${PORT}`);
});

