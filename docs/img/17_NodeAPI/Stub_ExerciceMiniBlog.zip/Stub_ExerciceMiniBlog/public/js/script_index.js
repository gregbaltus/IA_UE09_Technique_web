fetch("/api/articles")
  .then(response => response.json())
  .then(articles => {
    console.log("Articles récupérés :", articles);
    const container = document.getElementById("articles-container");

    articles.forEach(article => {
      const articleElement = document.createElement("article");

      articleElement.innerHTML = `
        <h2>${article.titre}</h2>
        <p>${article.contenu}</p>
        <a href="/article.html?id=${article.id}">Lire la suite</a>
      `;

      container.appendChild(articleElement);
    });
  })
  .catch(error => {
    console.error("Erreur lors du chargement des articles :", error);
  });