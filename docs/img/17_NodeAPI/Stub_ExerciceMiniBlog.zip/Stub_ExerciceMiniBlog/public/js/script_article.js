const params = new URLSearchParams(window.location.search);
const id = params.get("id");

if (!id) {
  document.getElementById("titre-article").textContent = "Aucun article sélectionné.";
} else {
  fetch(`/api/articles/${id}`)
    .then(response => {
      if (!response.ok) {
        throw new Error("Article introuvable");
      }
      return response.json();
    })
    .then(article => {
      document.getElementById("titre-article").textContent = article.titre;
      document.getElementById("contenu-article").textContent = article.contenu;
    })
    .catch(error => {
      document.getElementById("titre-article").textContent = "Erreur";
      document.getElementById("contenu-article").textContent = "Impossible de charger l'article.";
      console.error("Erreur :", error);
    });
}