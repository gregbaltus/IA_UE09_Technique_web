import sqlite3pkg from "sqlite3";
const sqlite3 = sqlite3pkg.verbose();

import path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

class ArticleRepository {
  constructor() {
    this.db = new sqlite3.Database(path.join(__dirname, "../data/articles.sqlite"));
  }

  getAllArticles(callback) {
    const query = "SELECT * FROM articles";
    this.db.all(query, [], (err, rows) => {
      if (err) return callback(err);
      callback(null, rows);
    });
  }

  getArticleById(id, callback) {
    const query = "SELECT * FROM articles WHERE id = ?";
    this.db.get(query, [id], (err, row) => {
      if (err) return callback(err);
      callback(null, row);
    });
  }

  insertArticle(titre, contenu, callback) {
    const query = "INSERT INTO articles (titre, contenu) VALUES (?, ?)";
    this.db.run(query, [titre, contenu], function (err) {
      if (err) return callback(err);
      callback(null, { id: this.lastID });
    });
  }
}

export default ArticleRepository;