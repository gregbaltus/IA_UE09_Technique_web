const sqlite3 = require("sqlite3").verbose();
const path = require("path");

class ArticleRepository {
  constructor() {
    // Connexion à la base de données
    this.db = new sqlite3.Database(path.join(__dirname, "../data/articles.sqlite"));
  }

  // Récupère tous les articles
  getAllArticles(callback) {
    const query = "SELECT * FROM articles";
    this.db.all(query, [], (err, rows) => {
      if (err) return callback(err);
      callback(null, rows);
    });
  }

  // Récupère un article par son id
  getArticleById(id, callback) {
    const query = "SELECT * FROM articles WHERE id = ?";
    this.db.get(query, [id], (err, row) => {
      if (err) return callback(err);
      callback(null, row);
    });
  }

  // Insère un nouvel article
  insertArticle(titre, contenu, callback) {
    const query = "INSERT INTO articles (titre, contenu) VALUES (?, ?)";
    this.db.run(query, [titre, contenu], function (err) {
      if (err) return callback(err);
      callback(null, { id: this.lastID });
    });
  }
}

module.exports = ArticleRepository;