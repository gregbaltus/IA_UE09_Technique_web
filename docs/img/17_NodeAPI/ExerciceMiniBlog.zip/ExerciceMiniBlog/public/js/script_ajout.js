const params = new URLSearchParams(window.location.search);
const etat = params.get("etat");
const messageElement = document.getElementById("message");

if (etat === "ok") {
  messageElement.textContent = "L'article a bien été ajouté.";
  messageElement.style.color = "green";
} else if (etat === "erreur") {
  messageElement.textContent = "Veuillez remplir tous les champs.";
  messageElement.style.color = "red";
}