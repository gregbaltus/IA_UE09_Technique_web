export {Persona, PersonaInYear};

/**
 * Conversion d'une année BY en année standard
 * @param {string} yearBY
 * @return {number}
 */
function convertYearBYToYear(yearBY){
    //TODO
}

/**
 * Conversion d'une année standard en année BY
 * @param {number} year
 * @return {string}
 */
function convertYearToYearBY(year){
    //TODO
}

/**
 * Classe représentant une personnalité
 */
class Persona {
    /**
     * Construit un Persona avec l'objet extrait de la liste des personnalités
     * @param {object} peopleItem
     */
    constructor(peopleItem){
        //TODO
        this.name;
        this.height;
        this.mass;
        this.birthDate;
        this.gender;
        this.BMI;
    }

    /**
     * Getter retourne la date de naissance en année BY
     * @return {string}
     */
    get birthDateBY(){
        //TODO
    }

    /**
     * Retourne l'âge en années standards pour une année BY
     * @param {string} year
     * @return {number}
     */
    getAge(year){
        //TODO
    }

    /**
     * Calcule l'IMG (FMI) pour une année BY
     * @param {string} year
     * @return {number}
     */
    getFMI(year){
        //TODO
    }

}

/**
 * Classe représentant une personnalité à une année BY
 */
class PersonaInYear extends Persona {
    /**
     * Construit une personnalité pour une année BY avec l'objet extrait de la liste des personnalités
     * @param {object} peopleItem
     * @param {string} yearBY
     */
    constructor(peopleItem, yearBY){
        //TODO
        this.age;
        this.FMI;
    }

    /**
     * Fonction statique qui retourne une fonction de comparaison selon le critère et l'ordre croissant/décroissant
     */
     compare(/*TODO  ?? */){
       //TODO  
     }
    
}