/*
    Ce fichier importe le fichier de données sw-people-list.js ainsi que le fichier sw-personna.js.
    Dans ce fichier, créez les fonctions nécessaires pour placer les gestionnaires d'événements et adapter le DOM en conséquence....
*/