const fruits = ["Pomme", "Banane", "Orange", "Fraise", "Mangue", "Raisin"];
